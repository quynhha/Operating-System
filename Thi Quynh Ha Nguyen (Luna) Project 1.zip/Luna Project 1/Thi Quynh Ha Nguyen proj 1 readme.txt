External document for Thi Quynh Ha Nguyen's CS 3013 project 1 program.

This program, called doit, takes another command as an argument and executes
that command
After execution of the specifed command has completed, "doit" should display 
statistics that show some of system
resources the command used. In particular, doit should print:
1. the amount of CPU time used (both user and system time) (in milliseconds),
2. the elapsed \wall-clock" time for the command to execute (in milliseconds),
3. the number of times the process was preempted involuntarily (e.g. time slice expired,
preemption by higher priority process),
4. the number of times the process gave up the CPU voluntarily (e.g. waiting for a re-
source),
5. the number of major page faults, which require disk I/O, and
6. the number of minor page faults, which could be satisfied without disk I/O.

This program also handle three \built-in" commands:
- exit (causes your shell to terminate)
- cd dir (causes your shell to change the directory to dir)
- set prompt = newprompt (causes your shell to change the prompt to newprompt)
- jobs (lists all background tasks)
To start the shell program, start the program with no argument 
(ie. "./doit" without quotes).
A prompt will show up asking for a command.
To exit, just enter "exit".
Furthermore, this shell program lets the user change directories.
To do so, type and enter "cd TestPatch" without quotes where TestPath is the specific path
you want to change directory to.
If there is an error, the system will display error message!!!
To indicate a task as a background task, simply put an ampersand (`&') character at the end
of an input line.
